import {
  addDays,
} from '../../utils/dates'
import {
  formatDateWithOrdinal,
} from '../../utils/formatters'
import {
  MEAL_PLAN_DEVIATION_TYPES as DEVIATION,
} from '../../utils/dailyCheckInFlow'
import {
  normalizeCheckInSettings,
} from '../../utils/checkInTracking'
import {
  getCardioContextLabel,
} from '../../utils/cardio'

const MEAL_PLAN_LABELS = {
  1: 'Did not follow the plan',
  2: 'Significantly off plan',
  3: 'Several deviations',
  4: 'One small deviation',
  5: 'Followed the plan exactly',
}

const HUNGER_LABELS = {
  1: 'Barely hungry',
  2: 'Comfortable',
  3: 'Noticeably hungry',
  4: 'Very hungry / distracting',
  5: 'Extremely hungry / hard to ignore',
}

const DEVIATION_LABELS = {
  [DEVIATION.CHEAT_ONLY]:
    'Planned cheat meal only',
  [DEVIATION.CHEAT_PLUS]:
    'Planned cheat meal plus other deviations',
  [DEVIATION.NO_CHEAT]:
    'No planned cheat meal involved',
}

const WORKOUT_LABELS = {
  completed: 'Completed',
  partial: 'Partially completed',
  missed: 'Did not complete',
  rest_day:
    'Rest day / no workout scheduled',
}

const WEIGHT_STATUS_LABELS = {
  traveling: 'No weight — traveling',
  no_scale:
    'No weight — no scale available',
  scale_issue:
    'No weight — scale problem',
  skipped:
    'Skipped weighing this morning',
}

function yesNo(value) {
  if (value === true) return 'Yes'
  if (value === false) return 'No'

  return 'Not answered'
}

function ReviewItem({ label, value }) {
  return (
    <div className="review-item">
      <dt>{label}:</dt>
      <dd>{value || 'None'}</dd>
    </div>
  )
}

export function DailyCheckInReview({
  form,
  target,
  today,
  settings,
  showCoachNotes = true,
  isHistorical = false,
}) {
  const {
    track_water: trackWater,
    track_alcohol: trackAlcohol,
  } = normalizeCheckInSettings(settings)
  const mealPlanScore = Number(
    form.meal_plan_score,
  )
  const waterGoal =
    target?.daily_water_goal_oz ?? 0

  const workoutWasAttempted = [
    'completed',
    'partial',
  ].includes(form.workout_status)

  const weightAnswer =
    form.weight_status === 'recorded'
      ? `${Number(
          form.morning_weight,
        ).toFixed(1)} lbs`
      : WEIGHT_STATUS_LABELS[
          form.weight_status
        ]

  const waterAnswer =
    form.water_goal_met === true
      ? `${waterGoal} / ${waterGoal} oz — Goal met`
      : `Goal not met — ${waterGoal} oz target`

  const reviewDate =
    addDays(today, -1)

  const showDeviation =
    mealPlanScore >= 1 &&
    mealPlanScore <= 4

  const showDeviationDetails = [
    DEVIATION.CHEAT_PLUS,
    DEVIATION.NO_CHEAT,
  ].includes(
    form.meal_plan_deviation_type,
  )

  return (
    <div className="checkin-review">
      <section>
        <h2>
          {isHistorical
            ? `Morning of ${formatDateWithOrdinal(today)}`
            : `This Morning, ${formatDateWithOrdinal(today)}`}
        </h2>

        <dl>
          <ReviewItem
            label="Morning weight"
            value={weightAnswer}
          />
        </dl>
      </section>

      <section>
        <h2>
          {isHistorical
            ? `About ${formatDateWithOrdinal(reviewDate)}`
            : `Yesterday, ${formatDateWithOrdinal(reviewDate)}`}
        </h2>

        <dl>
          <ReviewItem
            label="Meal-plan adherence"
            value={
              MEAL_PLAN_LABELS[
                mealPlanScore
              ]
            }
          />

          {showDeviation && (
            <ReviewItem
              label="What happened"
              value={
                DEVIATION_LABELS[
                  form
                    .meal_plan_deviation_type
                ]
              }
            />
          )}

          {showDeviationDetails && (
            <ReviewItem
              label={
                form
                  .meal_plan_deviation_type ===
                DEVIATION.CHEAT_PLUS
                  ? 'Other deviations'
                  : 'What was different'
              }
              value={
                form
                  .meal_plan_deviation_details
              }
            />
          )}

          <ReviewItem
            label="Overall hunger"
            value={
              HUNGER_LABELS[
                form.hunger_score
              ]
            }
          />

          <ReviewItem
            label="Workout"
            value={
              WORKOUT_LABELS[
                form.workout_status
              ]
            }
          />

          {form.workout_status ===
            'missed' && (
            <ReviewItem
              label="What prevented the workout"
              value={
                form
                  .workout_incomplete_reason
              }
            />
          )}

          {workoutWasAttempted && (
            <ReviewItem
              label="Pain, difficulty, or problems"
              value={yesNo(
                form.training_problem,
              )}
            />
          )}

          {workoutWasAttempted &&
            form.training_problem ===
              true && (
              <ReviewItem
                label="Training problem details"
                value={
                  form
                    .training_problem_details
                }
              />
            )}

          <ReviewItem
            label="Cardio"
            value={[
              `${form.cardio_minutes} minutes`,
              Number(form.cardio_minutes) > 0
                ? getCardioContextLabel({
                    cardioType:
                      form.cardio_type,
                    cardioIntensity:
                      form.cardio_intensity,
                  })
                : '',
            ]
              .filter(Boolean)
              .join(' · ')}
          />

          {trackWater && (
            <ReviewItem
              label="Water"
              value={waterAnswer}
            />
          )}

          {trackAlcohol && (
            <ReviewItem
              label="Alcohol"
              value={yesNo(
                form.alcohol_consumed,
              )}
            />
          )}

          {trackAlcohol &&
            form.alcohol_consumed ===
              true && (
            <ReviewItem
              label="What and how much"
              value={
                form.alcohol_details
              }
            />
          )}
        </dl>
      </section>

      {showCoachNotes && (
        <section>
          <h2>Coach Notes</h2>

          <dl>
            <ReviewItem
              label="Questions or notes for coach"
              value={
                form.coach_notes
              }
            />
          </dl>
        </section>
      )}
    </div>
  )
}
