import {
  useEffect,
  useState,
} from 'react'
import {
  formatGoal,
} from '../../utils/formatters'

function formatWeight(value) {
  return Number.isFinite(Number(value))
    ? `${Number(value).toFixed(1)} lbs`
    : '—'
}

function formatWeightChangeFromStart(averageWeight, startWeight) {
  const average = Number(averageWeight)
  const start = Number(startWeight)

  if (!Number.isFinite(average) || !Number.isFinite(start)) {
    return null
  }

  const difference = average - start

  if (Math.abs(difference) < 0.05) {
    return 'No change from Start'
  }

  const magnitude = Math.abs(difference).toFixed(1)
  return difference < 0
    ? `↓ ${magnitude} lbs from Start`
    : `↑ ${magnitude} lbs from Start`
}

function getPlanProgressRows(
  plan,
  currentWeekNumber,
  weeks,
) {
  const programLength = Number(
    plan?.program_length_weeks,
  )

  if (
    !Number.isInteger(programLength) ||
    programLength < 1
  ) {
    return []
  }

  const weekDataByNumber = new Map(
    (weeks ?? []).map(
      (week) => [
        Number(week.weekNumber),
        week,
      ],
    ),
  )

  return Array.from(
    {
      length: programLength,
    },
    (_, index) => {
      const weekNumber = index + 1
      const weekData =
        weekDataByNumber.get(
          weekNumber,
        )

      // A finalized week is completed even if it is the
      // last program week and there is no later "current" week.
      if (
        weekData?.weeklyStatus ===
        'completed'
      ) {
        return {
          ...weekData,
          weekNumber,
          status:
            weekData?.planAdjustmentStatus === 'proposed'
              ? 'recommendation-waiting'
              : 'completed',
        }
      }

      if (
        weekNumber ===
        currentWeekNumber
      ) {
        return {
          ...weekData,
          weekNumber,
          status: 'current',
        }
      }

      if (
        currentWeekNumber &&
        weekNumber <
          currentWeekNumber
      ) {
        if (weekData?.canCompleteWeekly) {
          return {
            ...weekData,
            weekNumber,
            status: 'weekly-overdue',
          }
        }

        if (
          weekData?.weeklyStatus ===
          'draft'
        ) {
          return {
            ...weekData,
            weekNumber,
            status: 'needs-review',
          }
        }

        return {
          ...weekData,
          weekNumber,
          status: 'no-weekly',
        }
      }

      return {
        weekNumber,
        status: 'upcoming',
      }
    },
  )
}

export function PlanProgress({
  plan,
  currentWeekNumber,
  weeks,
  startWeight,
  onOpenCurrentWeek,
  onOpenWeeklyReview,
  onOpenWeeklyCheckIn,
  onShowAllWeeks,
  initialShowAll = false,
}) {
  const [
    showAllWeeks,
    setShowAllWeeks,
  ] = useState(initialShowAll)

  // A dedicated Progress screen opens expanded, while the
  // Dashboard opens compact. Keep the component in sync if
  // it is reused with a different display mode.
  useEffect(() => {
    setShowAllWeeks(
      initialShowAll,
    )
  }, [initialShowAll, plan?.id])

  const rows =
    getPlanProgressRows(
      plan,
      currentWeekNumber,
      weeks,
    )

  const programLength = Number(
    plan?.program_length_weeks,
  )

  const defaultLastVisibleWeek =
    currentWeekNumber
      ? Math.min(
          programLength,
          currentWeekNumber + 2,
        )
      : Math.min(
          programLength,
          2,
        )

  const visibleRows =
    showAllWeeks
      ? rows
      : rows.filter(
          (row) =>
            row.weekNumber <=
            defaultLastVisibleWeek,
        )

  const hasHiddenWeeks =
    visibleRows.length < rows.length

  function renderWeightChange(row) {
    const weightChange = formatWeightChangeFromStart(
      row.averageWeight,
      startWeight,
    )

    return weightChange ? (
      <span className="plan-progress-weight-change">
        {weightChange}
      </span>
    ) : null
  }

  function renderRowContent(
    row,
  ) {
    if (
      row.status ===
      'recommendation-waiting'
    ) {
      return (
        <>
          <div className="plan-progress-row-topline">
            <strong>Week {row.weekNumber}</strong>
            <span className="plan-progress-status is-recommendation-waiting">
              Recommendation Waiting
            </span>
          </div>
          <span className="plan-progress-subtext">
            Review and decide
          </span>
        </>
      )
    }

    if (
      row.status ===
      'completed'
    ) {
      return (
        <>
          <div className="plan-progress-row-topline">
            <strong>
              Week {row.weekNumber}
            </strong>

            <span className="plan-progress-status is-complete">
              Completed ✓
            </span>
          </div>

          <div className="plan-progress-row-details">
            {Number.isFinite(
              Number(
                row.consistencyPercent,
              ),
            ) && (
              <span>
                Consistency{' '}
                <strong>
                  {Math.round(
                    row.consistencyPercent,
                  )}
                  %
                </strong>
              </span>
            )}

            {Number.isFinite(
              Number(
                row.averageWeight,
              ),
            ) && (
              <span>
                Avg Weight{' '}
                <strong>
                  {formatWeight(
                    row.averageWeight,
                  )}
                </strong>
              </span>
            )}
          </div>

          {renderWeightChange(row)}
        </>
      )
    }

    if (
      row.status ===
      'current'
    ) {
      return (
        <>
          <div className="plan-progress-row-topline">
            <strong>
              Week {row.weekNumber}
            </strong>

            <span className="plan-progress-status is-current">
              Current
            </span>
          </div>

          {Number.isFinite(Number(row.averageWeight)) ? (
            <>
              <div className="plan-progress-row-details">
                <span>
                  Avg Weight{' '}
                  <strong>{formatWeight(row.averageWeight)}</strong>
                </span>
              </div>
              {renderWeightChange(row)}
            </>
          ) : (
            <span className="plan-progress-subtext">
              In progress
            </span>
          )}
        </>
      )
    }

    if (
      row.status ===
      'needs-review'
    ) {
      return (
        <>
          <div className="plan-progress-row-topline">
            <strong>
              Week {row.weekNumber}
            </strong>

            <span className="plan-progress-status is-needs-review">
              Needs Review
            </span>
          </div>

          <span className="plan-progress-subtext">
            Weekly Check-In started but not finalized
          </span>
        </>
      )
    }

    if (
      row.status ===
      'weekly-overdue'
    ) {
      return (
        <>
          <div className="plan-progress-row-topline">
            <strong>
              Week {row.weekNumber}
            </strong>

            <span className="plan-progress-status is-overdue">
              Weekly Overdue
            </span>
          </div>

          <span className="plan-progress-subtext">
            Complete your Weekly Check-In while this week is still open
          </span>
        </>
      )
    }

    if (
      row.status ===
      'no-weekly'
    ) {
      const hasDailyData =
        Number(row.dailyCheckInCount) > 0

      return (
        <>
          <div className="plan-progress-row-topline">
            <strong>
              Week {row.weekNumber}
            </strong>

            <span className="plan-progress-status is-no-weekly">
              No Weekly Check-In
            </span>
          </div>

          {hasDailyData ? (
            <div className="plan-progress-row-details">
              <span>
                Daily Check-Ins{' '}
                <strong>
                  {Number(row.dailyCheckInCount)}
                </strong>
              </span>

              {Number.isFinite(
                Number(
                  row.averageWeight,
                ),
              ) && (
                <span>
                  Avg Weight{' '}
                  <strong>
                    {formatWeight(
                      row.averageWeight,
                    )}
                  </strong>
                </span>
              )}
            </div>
          ) : (
            <span className="plan-progress-subtext">
              No check-in data recorded
            </span>
          )}

          {hasDailyData && renderWeightChange(row)}
        </>
      )
    }

    return (
      <div className="plan-progress-row-topline">
        <strong>
          Week {row.weekNumber}
        </strong>

        <span className="plan-progress-status is-upcoming">
          Upcoming
        </span>
      </div>
    )
  }

  return (
    <section
      className="plan-progress-card"
      aria-labelledby="plan-progress-heading"
    >
      <header className="plan-progress-header">
        <h2 id="plan-progress-heading">
          Plan Progress
        </h2>

        <p>
          {formatGoal(plan.goal)}
          {currentWeekNumber
            ? ` · Week ${currentWeekNumber} of ${plan.program_length_weeks}`
            : ` · ${plan.program_length_weeks}-Week Plan`}
        </p>
      </header>

      <div className="plan-progress-list">
        {visibleRows.map(
          (row) => {
            if (
              row.status === 'completed' ||
              row.status === 'recommendation-waiting'
            ) {
              return (
                <button
                  type="button"
                  className={`plan-progress-row is-clickable ${
                    row.status === 'recommendation-waiting'
                      ? 'is-recommendation-waiting'
                      : 'is-completed'
                  }`}
                  key={
                    row.weekNumber
                  }
                  onClick={() =>
                    onOpenWeeklyReview(
                      row.weekNumber,
                    )
                  }
                  aria-label={`Open Week ${row.weekNumber} Weekly Review`}
                >
                  <span className="plan-progress-row-content">
                    {renderRowContent(
                      row,
                    )}
                  </span>

                  <span
                    className="plan-progress-chevron"
                    aria-hidden="true"
                  >
                    ›
                  </span>
                </button>
              )
            }

            if (
              row.status ===
                'weekly-overdue' &&
              onOpenWeeklyCheckIn
            ) {
              return (
                <button
                  type="button"
                  className="plan-progress-row is-clickable is-weekly-overdue"
                  key={row.weekNumber}
                  onClick={() =>
                    onOpenWeeklyCheckIn(
                      row.weeklyDueDate,
                    )
                  }
                  aria-label={`Complete Week ${row.weekNumber} Weekly Check-In`}
                >
                  <span className="plan-progress-row-content">
                    {renderRowContent(row)}
                  </span>

                  <span
                    className="plan-progress-chevron"
                    aria-hidden="true"
                  >
                    ›
                  </span>
                </button>
              )
            }

            if (
              row.status ===
              'current' &&
              onOpenCurrentWeek
            ) {
              return (
                <button
                  type="button"
                  className="plan-progress-row is-clickable is-current"
                  key={
                    row.weekNumber
                  }
                  onClick={
                    onOpenCurrentWeek
                  }
                  aria-label={`Open current Week ${row.weekNumber} Daily Check-Ins`}
                >
                  <span className="plan-progress-row-content">
                    {renderRowContent(
                      row,
                    )}
                  </span>

                  <span
                    className="plan-progress-chevron"
                    aria-hidden="true"
                  >
                    ›
                  </span>
                </button>
              )
            }

            return (
              <div
                className={`plan-progress-row is-${row.status}`}
                key={
                  row.weekNumber
                }
              >
                <span className="plan-progress-row-content">
                  {renderRowContent(
                    row,
                  )}
                </span>
              </div>
            )
          },
        )}
      </div>

      {!initialShowAll &&
        hasHiddenWeeks &&
        rows.length > 0 && (
          <button
            type="button"
            className="text-button plan-progress-toggle"
            onClick={
              onShowAllWeeks
                ? onShowAllWeeks
                : () =>
                    setShowAllWeeks(true)
            }
          >
            •••  Show All Weeks
          </button>
        )}
    </section>
  )
}
