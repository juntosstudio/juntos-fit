import {
  useEffect,
  useMemo,
  useState,
} from 'react'
import { StartCheckInStep } from '../components/startcheckin/StartCheckInStep'
import { StartCheckInReview } from '../components/startcheckin/StartCheckInReview'
import { useStartCheckIn } from '../hooks/useStartCheckIn'
import {
  useCheckInMeasurementValidation,
} from '../hooks/useCheckInMeasurementValidation'
import { useWizardFocus } from '../hooks/useWizardFocus'
import {
  getStartCheckInSteps,
  START_CHECKIN_STEP_IDS as STEP,
} from '../utils/startCheckInFlow'
import {
  canContinueMeasurementFields,
  START_VALIDATED_MEASUREMENT_FIELDS,
} from '../utils/measurementValidation'
import { formatDate } from '../utils/formatters'
import '../styles/wizard.css'
import '../styles/startCheckIn.css'

const START_PREVIEW_REQUEST_KEY =
  'juntos:start-checkin-preview'

const START_MEASUREMENT_INPUT_IDS = {
  starting_weight_lbs: 'start-weight',
  body_fat_percent: 'start-scale-body-fat',
  neck_inches:
    'start-measurement-neck_inches',
  chest_inches:
    'start-measurement-chest_inches',
  waist_inches:
    'start-measurement-waist_inches',
  hips_inches:
    'start-measurement-hips_inches',
  upper_arm_inches:
    'start-measurement-upper_arm_inches',
  thigh_inches:
    'start-measurement-thigh_inches',
  calf_inches:
    'start-measurement-calf_inches',
}

function getStepFields(step, form) {
  const fieldMap = {
    [STEP.WEIGHT]: [
      ['starting_weight_lbs', 'Starting weight'],
    ],
    [STEP.NECK]: [
      ['neck_inches', 'Neck'],
    ],
    [STEP.CHEST]: [
      ['chest_inches', 'Chest'],
    ],
    [STEP.WAIST]: [
      ['waist_inches', 'Waist'],
    ],
    [STEP.HIPS]: [
      ['hips_inches', 'Hips'],
    ],
    [STEP.SIDE_MEASUREMENTS]: [
      [
        'upper_arm_inches',
        `${form.measurement_side} upper arm`,
      ],
      [
        'thigh_inches',
        `${form.measurement_side} thigh`,
      ],
      [
        'calf_inches',
        `${form.measurement_side} calf`,
      ],
    ],
  }

  return fieldMap[step] ?? []
}

function hasStartedProgress(form, photos) {
  return (
    Object.entries(form).some(
      ([key, value]) =>
        key === 'body_fat_unavailable'
          ? value === true
          : value !== '',
    ) ||
    Object.values(photos).some(Boolean)
  )
}

// Displays the guided Start Check-In wizard.
export function StartCheckInPage({
  plan,
  onSaved,
  onBack,
}) {
  const {
    unitSystem,
    form,
    photos,
    estimatedBodyFat,
    isDirty,
    loading,
    saving,
    uploadingPose,
    error,
    successMessage,
    canEdit,
    isReadOnly,
    planHasStarted,
    isCompleted,
    resumeStep,
    saveMessage,
    setField,
    clearMessages,
    saveDraft,
    saveCheckIn,
    uploadPhoto,
  } = useStartCheckIn(plan, onSaved)

  const steps = useMemo(
    () => getStartCheckInSteps(plan),
    [plan],
  )

  const [currentStep, setCurrentStep] =
    useState(STEP.TIPS)
  const [reviewing, setReviewing] =
    useState(false)
  const [completionType, setCompletionType] =
    useState(null)
  const [previewing, setPreviewing] =
    useState(false)
  const [touchedFields, setTouchedFields] =
    useState({})
  useEffect(() => {
    if (
      !import.meta.env.DEV ||
      typeof window === 'undefined'
    ) {
      return
    }

    const previewRequested =
      window.sessionStorage.getItem(
        START_PREVIEW_REQUEST_KEY,
      ) === 'true'

    if (!previewRequested) {
      return
    }

    window.sessionStorage.removeItem(
      START_PREVIEW_REQUEST_KEY,
    )
    setPreviewing(true)
    setCurrentStep(STEP.TIPS)
    setReviewing(false)
    setCompletionType(null)
  }, [])

  const isViewOnly =
    isReadOnly && !previewing

  const measurementLabels =
    useMemo(() => {
      const side =
        form.measurement_side ||
        'chosen'

      return {
        starting_weight_lbs:
          'Starting weight',
        body_fat_percent:
          'Body fat',
        neck_inches: 'Neck',
        chest_inches: 'Chest',
        waist_inches: 'Waist',
        hips_inches: 'Hips',
        upper_arm_inches:
          `${side} upper arm`,
        thigh_inches:
          `${side} thigh`,
        calf_inches:
          `${side} calf`,
      }
    }, [form.measurement_side])

  const {
    validationByField,
    warningConfirmation,
    requestWarningConfirmation,
    confirmWarningValues,
    cancelWarningConfirmation,
  } = useCheckInMeasurementValidation({
    form,
    fields:
      START_VALIDATED_MEASUREMENT_FIELDS,
    unitSystem,
    labels: measurementLabels,
    inputIds:
      START_MEASUREMENT_INPUT_IDS,
  })

  const currentIndex =
    steps.indexOf(currentStep)
  const safeIndex =
    currentIndex >= 0 ? currentIndex : 0
  const activeStep =
    steps[safeIndex] ?? STEP.TIPS

  const {
    markForwardNavigation,
    markBackNavigation,
    focusField,
  } = useWizardFocus({
    stepKey: activeStep,
    rootId: 'start-checkin-wizard-step',
    reviewing,
    disabled: Boolean(
      completionType ||
      warningConfirmation,
    ),
  })



  const previewAvailable =
    import.meta.env.DEV && !planHasStarted
  const wizardAvailable =
    canEdit ||
    previewing ||
    isCompleted
  const startedProgress =
    hasStartedProgress(form, photos)

  const autosaveEnabled =
    !previewing &&
    canEdit &&
    !isCompleted

  const shouldPersistDraft =
    autosaveEnabled &&
    (
      isDirty ||
      Boolean(resumeStep) ||
      startedProgress
    )

  const pageTitle = previewing
    ? 'Preview Start Check-In'
    : isCompleted
    ? isViewOnly
      ? 'View Start Check-In'
      : 'Update Start Check-In'
    : startedProgress
      ? 'Continue Start Check-In'
      : 'Start Check-In'

  useEffect(() => {
    if (
      loading ||
      isCompleted ||
      !resumeStep
    ) {
      return
    }

    if (resumeStep === 'review') {
      setReviewing(true)
      return
    }

    if (steps.includes(resumeStep)) {
      setReviewing(false)
      setCurrentStep(resumeStep)
    }
  }, [
    isCompleted,
    loading,
    resumeStep,
    steps,
  ])

  function markFieldTouched(field) {
    setTouchedFields((current) => ({
      ...current,
      [field]: true,
    }))
  }

  function touchStepFields(step) {
    const fields = getStepFields(step, form)

    setTouchedFields((current) => ({
      ...current,
      ...Object.fromEntries(
        fields.map(([field]) => [
          field,
          true,
        ]),
      ),
      ...(step === STEP.BODY_FAT
        ? { body_fat_percent: true }
        : {}),
    }))
  }

  function getStepValidationFields(step) {
    const fields =
      getStepFields(step, form).map(
        ([field]) => field,
      )

    if (
      step === STEP.BODY_FAT &&
      plan.body_fat_source === 'scale' &&
      !form.body_fat_unavailable
    ) {
      fields.push('body_fat_percent')
    }

    return fields
  }

  function stepCanContinue(step) {
    if (
      isViewOnly ||
      step === STEP.TIPS
    ) {
      return true
    }

    if (step === STEP.WEIGHT) {
      if (!form.starting_weight_status) {
        return false
      }

      if (
        form.starting_weight_status !==
        'recorded'
      ) {
        return true
      }

      return canContinueMeasurementFields(
        ['starting_weight_lbs'],
        validationByField,
      )
    }

    if (step === STEP.BODY_FAT) {
      if (
        plan.body_fat_source ===
        'juntos_estimate'
      ) {
        return Boolean(estimatedBodyFat)
      }

      if (form.body_fat_unavailable) {
        return true
      }

      return canContinueMeasurementFields(
        ['body_fat_percent'],
        validationByField,
      )
    }

    const stepFields =
      getStepFields(step, form)

    if (stepFields.length > 0) {
      return canContinueMeasurementFields(
        stepFields.map(([field]) => field),
        validationByField,
      )
    }

    if (step === STEP.SIDE) {
      return Boolean(form.measurement_side)
    }

    if (step === STEP.FRONT_PHOTO) {
      return previewing || Boolean(photos.front)
    }

    if (step === STEP.SIDE_PHOTO) {
      return (
        previewing ||
        photos.side?.side_view ===
          form.measurement_side
      )
    }

    if (step === STEP.BACK_PHOTO) {
      return previewing || Boolean(photos.back)
    }

    return true
  }

  async function advanceFromCurrentStep() {
    const nextStep = steps[safeIndex + 1]
    const resumeAt =
      nextStep ?? 'review'

    clearMessages()

    markForwardNavigation()

    if (shouldPersistDraft) {
      const saved =
        await saveDraft(resumeAt)

      if (!saved) {
        return
      }
    }

    if (!nextStep) {
      setReviewing(true)
      return
    }

    setCurrentStep(nextStep)
  }

  async function skipBodyFatAndAdvance() {
    await advanceFromCurrentStep()
  }

  async function goNext() {
    touchStepFields(activeStep)

    if (!stepCanContinue(activeStep)) {
      return
    }

    if (
      requestWarningConfirmation(
        getStepValidationFields(
          activeStep,
        ),
      )
    ) {
      return
    }

    await advanceFromCurrentStep()
  }

  function editWarningValue() {
    const inputId =
      warningConfirmation
        ?.warnings?.[0]?.inputId

    cancelWarningConfirmation()

    if (inputId) {
      focusField(
        inputId,
        {
          selectAll: true,
          preventScroll: false,
        },
      )
    }
  }

  async function confirmWarnings() {
    confirmWarningValues()
    await advanceFromCurrentStep()
  }

  async function goBack() {
    clearMessages()
    markBackNavigation()

    if (reviewing) {
      const previous =
        steps.at(-1) ?? STEP.TIPS

      if (shouldPersistDraft) {
        const saved =
          await saveDraft(previous)

        if (!saved) {
          return
        }
      }

      setReviewing(false)
      setCurrentStep(previous)
      return
    }

    const previous = steps[safeIndex - 1]

    if (!previous) {
      return
    }

    if (shouldPersistDraft) {
      const saved =
        await saveDraft(previous)

      if (!saved) {
        return
      }
    }

    setCurrentStep(previous)
  }

  async function handleExit() {
    if (saving) {
      return
    }

    if (shouldPersistDraft) {
      const resumeAt =
        reviewing
          ? 'review'
          : activeStep

      const saved =
        await saveDraft(resumeAt)

      if (!saved) {
        return
      }
    }

    onBack?.()
  }

  async function handleComplete() {
    if (previewing || !canEdit) {
      return
    }

    const invalidStep = steps.find(
      (step) => !stepCanContinue(step),
    )

    if (invalidStep) {
      markForwardNavigation()
      setReviewing(false)
      setCurrentStep(invalidStep)
      touchStepFields(invalidStep)
      return
    }

    const wasCompleted = isCompleted
    const saved = await saveCheckIn({
      complete: true,
    })

    if (saved) {
      setCompletionType(
        wasCompleted ? 'updated' : 'completed',
      )
    }
  }

  function startPreview() {
    markForwardNavigation()
    setPreviewing(true)
    setCurrentStep(STEP.TIPS)
    setReviewing(false)
    setCompletionType(null)
  }

  const confirmation = completionType ? (
    <div className="confirmation-overlay">
      <section
        className="confirmation-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="start-confirmation-title"
      >
        <div
          className="confirmation-checkmark"
          aria-hidden="true"
        >
          ✓
        </div>

        <h2 id="start-confirmation-title">
          {completionType === 'updated'
            ? 'Start Check-In Updated'
            : 'Start Check-In Complete'}
        </h2>

        <p>
          {completionType === 'updated'
            ? 'Your starting baseline changes have been saved.'
            : 'Your starting baseline is saved. Your plan is officially underway.'}
        </p>

        <button type="button" onClick={onBack}>
          Back to Dashboard
        </button>
      </section>
    </div>
  ) : null

  const warningDialog =
    warningConfirmation ? (
      <div className="confirmation-overlay">
        <section
          className="confirmation-dialog measurement-warning-dialog"
          role="dialog"
          aria-modal="true"
          aria-labelledby="measurement-warning-title"
        >
          <h2 id="measurement-warning-title">
            Please Double-Check
          </h2>

          {warningConfirmation.warnings.map(
            (warning) => (
              <p key={warning.key}>
                {warning.validation.message}
              </p>
            ),
          )}

          <div className="wizard-actions">
            <button
              type="button"
              onClick={editWarningValue}
            >
              Edit Value
            </button>

            <button
              type="button"
              onClick={confirmWarnings}
            >
              Use This Value
            </button>
          </div>
        </section>
      </div>
    ) : null

  if (loading) {
    return (
      <main className="container start-checkin-page">
        <button type="button" onClick={onBack}>
          Back to Dashboard
        </button>

        <h1>Start Check-In</h1>
        <p>Loading your starting baseline...</p>
      </main>
    )
  }

  if (!plan) {
    return (
      <main className="container start-checkin-page">
        <button type="button" onClick={onBack}>
          Back to Dashboard
        </button>

        <h1>Start Check-In</h1>
        <p role="alert">
          No active coaching plan was found.
        </p>
      </main>
    )
  }

  if (!wizardAvailable) {
    return (
      <main className="container start-checkin-page">
        <button type="button" onClick={onBack}>
          Back to Dashboard
        </button>

        <h1>Start Check-In</h1>

        <p>
          Your Start Check-In will be available on your
          plan start date.
        </p>

        <p>
          Your plan starts{' '}
          <strong>
            {formatDate(plan.start_date)}
          </strong>
          .
        </p>

        {previewAvailable && (
          <button type="button" onClick={startPreview}>
            Preview Start Check-In Wizard
          </button>
        )}
      </main>
    )
  }

  if (reviewing) {
    return (
      <>
        <main className="container start-checkin-page">
          <button
            type="button"
            disabled={saving}
            onClick={
              autosaveEnabled
                ? handleExit
                : onBack
            }
          >
            {autosaveEnabled
              ? 'Exit Check-In'
              : 'Back to Dashboard'}
          </button>

          {autosaveEnabled && (
            <p className="wizard-question-helper" role="status">
              Autosave is on
              {saveMessage
                ? ` · ${saveMessage}`
                : ''}
            </p>
          )}

          <h1>
            {isViewOnly
              ? 'Starting Baseline'
              : isCompleted
                ? 'Review Your Changes'
                : 'Review Your Starting Baseline'}
          </h1>

          {isViewOnly && (
            <p className="start-lock-notice">
              This baseline is locked because the plan
              start date has passed.
            </p>
          )}

          <StartCheckInReview
            plan={plan}
            form={form}
            photos={photos}
            estimatedBodyFat={
              estimatedBodyFat
            }
            unitSystem={unitSystem}
          />

          {(error || successMessage) && (
            <p role={error ? 'alert' : 'status'}>
              {error || successMessage}
            </p>
          )}

          <div className="wizard-actions">
            <button
              type="button"
              disabled={saving}
              onClick={goBack}
            >
              {isViewOnly
                ? 'View Answers'
                : 'Edit Answers'}
            </button>

            {!isViewOnly && (
              <button
                type="button"
                disabled={
                  saving ||
                  previewing ||
                  (isCompleted && !isDirty)
                }
                onClick={handleComplete}
              >
                {saving
                  ? 'Saving...'
                  : isCompleted
                    ? 'Save Changes'
                    : 'Complete Start Check-In'}
              </button>
            )}
          </div>

          {previewing && (
            <p role="status">
              Preview mode — photos and submission are
              disabled.
            </p>
          )}
        </main>

        {confirmation}
        {warningDialog}
      </>
    )
  }

  const progress =
    ((safeIndex + 1) / steps.length) * 100

  return (
    <>
      <main className="container start-checkin-page">
        <button
          type="button"
          disabled={saving}
          onClick={
            autosaveEnabled
              ? handleExit
              : onBack
          }
        >
          {autosaveEnabled
            ? 'Exit Check-In'
            : 'Back to Dashboard'}
        </button>

        {autosaveEnabled && (
          <p className="wizard-question-helper" role="status">
            Autosave is on
            {saveMessage
              ? ` · ${saveMessage}`
              : ''}
          </p>
        )}

        <h1>{pageTitle}</h1>
        <p>{formatDate(plan.start_date)}</p>

        {isViewOnly && (
          <p className="start-lock-notice">
            This baseline is locked and view-only.
          </p>
        )}

        {previewing && (
          <p role="status">
            Preview mode — photos and submission are
            disabled.
          </p>
        )}

        {(error || successMessage) && (
          <p role={error ? 'alert' : 'status'}>
            {error || successMessage}
          </p>
        )}

        <progress
          max="100"
          value={progress}
          aria-label="Start Check-In progress"
        />

        <p>
          Question {safeIndex + 1} of {steps.length}
        </p>

        <div id="start-checkin-wizard-step">
          <StartCheckInStep
            step={activeStep}
          plan={plan}
          form={form}
          photos={photos}
          estimatedBodyFat={estimatedBodyFat}
          unitSystem={unitSystem}
          validationByField={validationByField}
          touchedFields={touchedFields}
          markFieldTouched={markFieldTouched}
          setField={setField}
          uploadPhoto={uploadPhoto}
          uploadingPose={uploadingPose}
          previewing={previewing}
          readOnly={isViewOnly}
            sideLocked={isCompleted}
            onSkipBodyFat={
              skipBodyFatAndAdvance
            }
          />
        </div>

        <div className="wizard-actions">
          <button
            type="button"
            disabled={safeIndex === 0}
            onClick={goBack}
          >
            Back
          </button>

          <button
            type="button"
            disabled={!stepCanContinue(activeStep)}
            onClick={goNext}
          >
            {safeIndex === steps.length - 1
              ? isViewOnly
                ? 'Review Baseline'
                : isCompleted
                  ? 'Review Changes'
                  : 'Review Baseline'
              : 'Next'}
          </button>
        </div>

        {!previewing &&
          canEdit &&
          isCompleted &&
          isDirty && (
            <div className="start-save-progress">
              <button
                type="button"
                disabled={saving}
                onClick={() =>
                  saveCheckIn({
                    complete: true,
                  })
                }
              >
                {saving
                  ? 'Saving...'
                  : 'Save Changes'}
              </button>
            </div>
          )}
      </main>

      {confirmation}
      {warningDialog}
    </>
  )
}
