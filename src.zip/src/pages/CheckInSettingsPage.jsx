import {
  useEffect,
  useState,
} from 'react'
import {
  WizardChoiceGroup,
  WizardPage,
  WizardQuestion,
} from '../components/wizard'
import {
  saveCheckInSettings,
} from '../services/checkInSettingsService'
import {
  normalizeCheckInSettings,
} from '../utils/checkInTracking'
import {
  BODY_FAT_SOURCE_OPTIONS,
} from '../utils/createPlanFlow'
import {
  getErrorMessage,
  logDevelopmentError,
} from '../utils/errors'
import '../styles/wizard.css'
import '../styles/checkInSettings.css'

const YES_NO_OPTIONS = [
  { value: true, label: 'Yes' },
  { value: false, label: 'No' },
]

export function CheckInSettingsPage({
  userId,
  profile,
  initialSettings,
  onSaved,
  onOpenToday,
  onOpenHistory,
  onOpenPlan,
}) {
  const normalizedInitial =
    normalizeCheckInSettings(
      initialSettings,
    )

  const [form, setForm] = useState(
    normalizedInitial,
  )
  const [savedForm, setSavedForm] =
    useState(normalizedInitial)
  const [saving, setSaving] =
    useState(false)
  const [error, setError] =
    useState('')
  const [success, setSuccess] =
    useState('')

  useEffect(() => {
    const next =
      normalizeCheckInSettings(
        initialSettings,
      )

    setForm(next)
    setSavedForm(next)
  }, [
    initialSettings?.track_water,
    initialSettings?.track_alcohol,
    initialSettings?.track_menstrual_cycle_context,
    initialSettings?.body_fat_source,
  ])

  function setField(field, value) {
    setForm((current) => ({
      ...current,
      [field]: value,
    }))
    setError('')
    setSuccess('')
  }

  async function saveSettings() {
    setSaving(true)
    setError('')
    setSuccess('')

    try {
      const saved =
        await saveCheckInSettings(
          userId,
          form,
        )

      const normalized =
        normalizeCheckInSettings(saved)

      setForm(normalized)
      setSavedForm(normalized)
      setSuccess(
        'Settings saved. Future check-ins will use these choices.',
      )

      await onSaved?.()
    } catch (saveError) {
      logDevelopmentError(
        'CheckInSettingsPage.saveSettings',
        saveError,
      )

      setError(
        getErrorMessage(
          saveError,
          'Your check-in settings could not be saved.',
        ),
      )
    } finally {
      setSaving(false)
    }
  }

  const isDirty =
    JSON.stringify(form) !==
    JSON.stringify(savedForm)

  return (
    <>
      <WizardPage
        className="checkin-settings-page"
        title="Check-In Settings"
        subtitle="Choose what Juntos Fit asks you to track."
        status={
          error || success ? (
            <p
              role={error ? 'alert' : 'status'}
            >
              {error || success}
            </p>
          ) : null
        }
        actions={
          <div className="settings-save-action">
            <button
              type="button"
              disabled={
                saving || !isDirty
              }
              onClick={saveSettings}
            >
              {saving
                ? 'Saving...'
                : 'Save Settings'}
            </button>
          </div>
        }
      >
      <WizardQuestion
        title="Do you want to track water in your check-ins?"
        helper="Turn this off and future Daily and Weekly Check-Ins will stop asking whether you met your water goal."
      >
        <WizardChoiceGroup
          name="track-water"
          value={form.track_water}
          options={YES_NO_OPTIONS}
          onChange={(value) =>
            setField(
              'track_water',
              value,
            )
          }
        />
      </WizardQuestion>

      <WizardQuestion
        title="Do you want to track alcohol in your check-ins?"
        helper="Turn this off and future Daily and Weekly Check-Ins will stop asking about alcohol."
      >
        <WizardChoiceGroup
          name="track-alcohol"
          value={form.track_alcohol}
          options={YES_NO_OPTIONS}
          onChange={(value) =>
            setField(
              'track_alcohol',
              value,
            )
          }
        />
      </WizardQuestion>

      {profile?.sex === 'female' && (
        <WizardQuestion
          title="Do you want to track menstrual cycle context?"
          helper="Turn this on and future Weekly Check-Ins will include an optional menstrual-cycle question so Juntos can consider cycle-related changes in weight, hunger, energy, and recovery."
        >
          <WizardChoiceGroup
            name="track-menstrual-cycle-context"
            value={
              form.track_menstrual_cycle_context
            }
            options={YES_NO_OPTIONS}
            onChange={(value) =>
              setField(
                'track_menstrual_cycle_context',
                value,
              )
            }
          />
        </WizardQuestion>
      )}

      <WizardQuestion
        title="How should body fat be tracked?"
        helper="This choice applies to future Weekly Check-Ins. Changing it later never rewrites earlier body-fat values or their original source."
      >
        <WizardChoiceGroup
          name="body-fat-source"
          value={form.body_fat_source}
          options={BODY_FAT_SOURCE_OPTIONS}
          onChange={(value) =>
            setField(
              'body_fat_source',
              value,
            )
          }
        />
      </WizardQuestion>

        <p className="wizard-question-helper">
          Changing these settings never deletes answers
          from earlier check-ins.
        </p>
      </WizardPage>

      <nav
        className="bottom-navigation"
        aria-label="Main navigation"
      >
        <button
          type="button"
          onClick={onOpenToday}
        >
          Today
        </button>

        <button
          type="button"
          onClick={onOpenHistory}
        >
          Progress
        </button>

        <button
          type="button"
          onClick={onOpenPlan}
        >
          Plan
        </button>

        <button
          type="button"
          disabled
        >
          Coach
        </button>

        <button
          type="button"
          className="is-active"
          aria-current="page"
        >
          Settings
        </button>
      </nav>
    </>
  )
}
